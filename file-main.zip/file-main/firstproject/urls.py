"""
URL configuration for firstproject project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.http import HttpResponse


def my_home_page(request):
    name = "J.MOHAMED HAFEEL"
    ref_no = "26018947"

    return HttpResponse(
        f"<h1>Name: {name}</h1>"
        f"<p>Register Number: {ref_no}</p>"
    )


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', my_home_page),
]